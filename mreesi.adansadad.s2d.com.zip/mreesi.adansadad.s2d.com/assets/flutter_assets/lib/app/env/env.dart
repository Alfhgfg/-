import 'package:get/get.dart';
import 'package:sadad_pos/app/modules/setting_app_module/setting_app_controller.dart';

var settingApp = Get.find<SettingAppController>();

class Env {
  static String appLogo = "assets/images/app_logo.png";
static const String appName = "المريسي سداد";
static late String appVer = "2.0.0.78+20078";
static late String oCode = "93";
static late String cKey = "mreesi-93-002:$version";

  static String baseUrlApi = settingApp.getServerUrl();

static late String version ="20078";
 late String primaryColor = "#f80201";
  // "#FDB040";
 late String secoundaryColor = "#020202";
  // "#25235F";
 static late String linkapp =
     "https://play.google.com/store/apps/details?id=mreesi.adansadad.s2d.com&hl=en_IN&gl=US";

  // late String appLogo;

  //firebase
 static const String baseStorgeUrl ="https://firebasestorage.googleapis.com/v0/b/sadad4.appspot.com/o/";


static const String nameAppTheme = "mreesi-93-002";
  static const String invoice = appName;
}
